export interface QuizFormData {
  firstName: string;
  surname: string;
  email: string;
  confirmEmail: string;
}